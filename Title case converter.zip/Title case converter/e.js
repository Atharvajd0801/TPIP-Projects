function convertToTitleCase() {
    const inputField = document.getElementById('inputText');
    const warningMessage = document.getElementById('warningMessage');

    // Check character limit
    if (inputField.value.length >= inputField.maxLength) {
        warningMessage.style.display = 'block';
    } else {
        warningMessage.style.display = 'none';
    }

    // Get and clean input text
    const inputText = inputField.value.trim();
    const cleanedText = inputText.replace(/\s+/g, ' ');
    
    // Common words that shouldn't be capitalized
    const lowercaseWords = ["and", "or", "the", "in", "on", "at", "for", "to", "a", "an", "but", "by", "with"];
    const capitalizeCommonWords = document.getElementById('capitalizeToggle').checked;
    
    // Split cleaned text and convert words
    const words = cleanedText.toLowerCase().split(' ');
    const titleCasedWords = words.map((word, index) => 
        (index === 0 || (capitalizeCommonWords && !lowercaseWords.includes(word)))
            ? word.charAt(0).toUpperCase() + word.slice(1)
            : word
    );

    // Join words back into a sentence
    const titleCaseText = titleCasedWords.join(' ');
    document.getElementById('outputText').innerText = titleCaseText;

    // Update word and character count
    const wordCount = words.filter(word => word !== "").length;
    const characterCount = cleanedText.replace(/\s/g, '').length;
    document.getElementById('wordCount').innerText = `Words: ${wordCount} | Characters: ${characterCount}`;
}

// Copy to Clipboard Function
function copyToClipboard() {
    const outputText = document.getElementById('outputText').innerText;
    navigator.clipboard.writeText(outputText).then(() => {
        alert("Text copied to clipboard!");
    }).catch(err => {
        console.error('Could not copy text: ', err);
    });
}

// Clear Text Function
function clearText() {
    document.getElementById('inputText').value = '';
    document.getElementById('outputText').innerText = '';
    document.getElementById('wordCount').innerText = 'Words: 0 | Characters: 0';
    document.getElementById('warningMessage').style.display = 'none';
}
